from boosting import *
from capmonster_python import *
import yaml
from colorama import Fore
import httpx, random, time, datetime, json, os, hashlib
from keyauth import *
if os.name == 'nt':
    import ctypes

def cls(): #clears the terminal
    os.system('cls' if os.name =='nt' else 'clear')

if os.name == "nt":
    ctypes.windll.kernel32.SetConsoleTitleW(f"M6ve Services | discord.gg/m6ve")
else:
    pass
    
with open("config.yaml") as f:
    config = yaml.load(f, Loader=yaml.FullLoader)

def getchecksum():
    md5_hash = hashlib.md5()
    file = open(''.join(sys.argv), "rb")
    md5_hash.update(file.read())
    digest = md5_hash.hexdigest()
    return digest

keyauthapp = api(
    name = "Boost Tool",
    ownerid = "t8n2jIVBqK",
    secret = "819b736c417229b5486c0c867f1499bb5976263733fdac088845b53a969606fa",
    version = "1.0",
    hash_to_check = getchecksum()
)
cls()

if keyauthapp.checkblacklist():
    print(Fore.RED + "You are blacklisted from our system." + Fore.RESET)
    quit()
    
def validate():
    if keyauthapp.license(config["license_key"]):
        quit()
    else:
        print(f"{Fore.MAGENTA}[{Fore.GREEN}SUCCESS{Fore.MAGENTA}]{Fore.LIGHTBLUE_EX} Successfully logged into License."+ Fore.RESET)
        time.sleep(2)
        

def answer():
    try:
        key = input(Fore.LIGHTBLUE_EX + """License Key: """+ Fore.RESET)
        x = {"license_key": key}
        config.update(x)
        json.dump(config, open("config.json", "w"), indent = 4)

    except KeyboardInterrupt:
        os._exit(1)

if "license_key" not in str(config):
    answer()

validate()


def getinviteCode(invite_input): #gets invite CODE
    if "discord.gg" not in invite_input:
        return invite_input
    if "discord.gg" in invite_input:
        invite = invite_input.split("discord.gg/")[1]
        return invite
    if "https://discord.gg" in invite_input:
        invite = invite_input.split("https://discord.gg/")[1]
        return invite
    if "invite" in invite_input:
        invite = invite_input.split("/invite/")[1]
        return invite

def menu():
    print(Fore.LIGHTBLUE_EX + '''
 █████╗ ███████╗███████╗ █████╗ ███████╗███████╗██╗███╗   ██╗    ██████╗  ██████╗  ██████╗ ███████╗████████╗
██╔══██╗██╔════╝██╔════╝██╔══██╗██╔════╝██╔════╝██║████╗  ██║    ██╔══██╗██╔═══██╗██╔═══██╗██╔════╝╚══██╔══╝
███████║███████╗███████╗███████║███████╗███████╗██║██╔██╗ ██║    ██████╔╝██║   ██║██║   ██║███████╗   ██║   
██╔══██║╚════██║╚════██║██╔══██║╚════██║╚════██║██║██║╚██╗██║    ██╔══██╗██║   ██║██║   ██║╚════██║   ██║   
██║  ██║███████║███████║██║  ██║███████║███████║██║██║ ╚████║    ██████╔╝╚██████╔╝╚██████╔╝███████║   ██║   
╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝╚═╝  ╚═══╝    ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝   ╚═╝   
                                                                                                                                                                                                                                                         
1. Boost Server
2. View Stock
3. Check Capmonster Balance
4. Quit
          ''' + Fore.RESET)
    
    choice = input(f"{Fore.LIGHTBLUE_EX}[>] " + Fore.RESET)
    
    if choice == "1":
        invite = getinvitCode(input(f"{Fore.MAGENTA}[{Fore.GREEN}INPUT{Fore.MAGENTA}] {Fore.LIGHTBLUE_EX}Invite Link/Code (Example: discord.gg/m6ve / m6ve): {Fore.RESET}"))
        amount = input(f"{Fore.MAGENTA}[{Fore.GREEN}INPUT{Fore.MAGENTA}] {Fore.LIGHTBLUE_EX}Amount of Boosts: {Fore.RESET}")
        while amount.isdigit() != True:
            print(Fore.LIGHTBLUE_EX + "Amount cannot be a string." + Fore.RESET)
            amount = input(f"{Fore.MAGENTA}[{Fore.GREEN}INPUT{Fore.MAGENTA}]{Fore.LIGHTBLUE_EX}Amount of Boosts: {Fore.RESET}")
        months = input(f"{Fore.MAGENTA}[{Fore.GREEN}INPUT{Fore.MAGENTA}] {Fore.LIGHTBLUE_EX}Number of months: {Fore.RESET}")
        while amount.isdigit() != True:
            print(Fore.LIGHTBLUE_EX + "Months cannot be a string." + Fore.RESET)
            months = input(f"{Fore.LIGHTBLUE_EX}Number of months: {Fore.RESET}")
        start = time.time()
        boosted = thread_boost(invite, int(amount), int(months), config['nickname'])
        end = time.time()
        print()
        sprint(f"Boosted https://discord.gg/{invite} {variables.boosts_done} times in {round(end - start, 2)} seconds.", True)
        print()
        input(f"{Fore.MAGENTA}[{Fore.GREEN}INPUT{Fore.MAGENTA}]{Fore.LIGHTBLUE_EX} Press enter to return to menu" + Fore.RESET)
        cls()
        menu()
        
    if choice == "2":
        print(f'{Fore.LIGHTBLUE_EX}1 Month Nitro Tokens: {len(open("input/1m_tokens.txt", "r").readlines())}{Fore.RESET}')
        print(f'{Fore.LIGHTBLUE_EX}1 Month Boosts: {len(open("input/1m_tokens.txt", "r").readlines())*2}{Fore.RESET}')
        print()
        print(f'{Fore.LIGHTBLUE_EX}3 Month Nitro Tokens: {len(open("input/3m_tokens.txt", "r").readlines())}{Fore.RESET}')
        print(f'{Fore.LIGHTBLUE_EX}3 Month Nitro Tokens: {len(open("input/3m_tokens.txt", "r").readlines())*2}{Fore.RESET}')
        print()
        input(Fore.LIGHTBLUE_EX + "Press enter to return to menu" + Fore.RESET)
        cls()
        menu()


        
    if choice == "3":
            Fore.RESET
            balance = requests.post(
                "https://api.capmonster.cloud/getBalance", json={
                    'clientKey': config['capmonster_key']
                }
            ).json()["balance"]
            print(f'{Fore.MAGENTA}[{Fore.GREEN}SUCCESS{Fore.MAGENTA}]{Fore.LIGHTBLUE_EX} {balance}')
            input(Fore.LIGHTBLUE_EX + "Press enter to return to menu" + Fore.RESET)
            cls()
            menu()
    if choice == "4":
        quit()

        
if __name__ == "__main__":
    cls()
    menu()
